using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace M295_Project_V1._0.pages
{
    public class fullpageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
